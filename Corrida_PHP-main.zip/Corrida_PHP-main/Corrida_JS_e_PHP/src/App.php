<?php
echo "App.php rodando..."; ?>